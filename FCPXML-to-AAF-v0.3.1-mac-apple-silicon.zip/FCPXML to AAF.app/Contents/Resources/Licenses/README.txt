FCPXML to AAF bundles these open-source components:
- Python 3.12 (python-build-standalone): PSF License, see Python-LICENSE.txt
- pyaaf2: MIT License, see pyaaf2-LICENSE.txt
- pywebview: BSD License; PyObjC: MIT License
- FFmpeg (static builds distributed with imageio-ffmpeg): GPL. Source code: https://ffmpeg.org/download.html
